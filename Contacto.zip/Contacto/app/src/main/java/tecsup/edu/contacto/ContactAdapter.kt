package tecsup.edu.contacto

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListAdapter
import android.widget.TextView

class ContactAdapter(private val context: Context, private val contacts: List<Contact>) :
    BaseAdapter(), ListAdapter {

    override fun getCount(): Int {
        return contacts.size
    }

    override fun getItem(position: Int): Any {
        return contacts[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.list_item_contact, parent, false)
        }

        val nameText = view!!.findViewById<TextView>(R.id.nameText)
        val emailText = view.findViewById<TextView>(R.id.emailText)
        val phoneText = view.findViewById<TextView>(R.id.phoneText)

        val contact = contacts[position]

        nameText.text = contact.name
        emailText.text = contact.email
        phoneText.text = contact.phone

        return view
    }
}