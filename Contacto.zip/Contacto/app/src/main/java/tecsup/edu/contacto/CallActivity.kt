package tecsup.edu.contacto

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CallActivity : AppCompatActivity() {

    private lateinit var nameText: TextView
    private lateinit var phoneText: TextView
    private lateinit var callButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        nameText = findViewById(R.id.nameText)
        phoneText = findViewById(R.id.phoneText)
        callButton = findViewById(R.id.callButton)

        val name = intent.getStringExtra("name")
        val phone = intent.getStringExtra("phone")

        nameText.text = name
        phoneText.text = phone

        callButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            startActivity(intent)
        }

    }
}
