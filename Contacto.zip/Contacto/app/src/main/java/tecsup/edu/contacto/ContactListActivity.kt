package tecsup.edu.contacto

import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.startActivity

class ContactListActivity : AppCompatActivity() {

    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_list)

        listView = findViewById(R.id.listView)
        val contacts = generateContacts()
        val adapter = ContactAdapter(this, contacts)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val contact = contacts[position]
            val intent = Intent(this, CallActivity::class.java)
            intent.putExtra("name", contact.name)
            intent.putExtra("phone", contact.phone)
            startActivity(intent)
        }
    }

    private fun generateContacts(): List<Contact> {
        val contacts = mutableListOf<Contact>()

        contacts.add(Contact("Jordi De La cruz", "jordi.delacruz@gmail.com", "900685788"))
        contacts.add(Contact("David Jimenez", "David.jimenez@gmail.com", "951720566"))
        contacts.add(Contact("Yenifer Vargas ", "yenifer.vargas@gmial.com", "928621665"))
        contacts.add(Contact("Yeromi Zavala", "yeromi.zavala@gmail.com", "9285547771"))
        contacts.add(Contact("David Ruiz", "david.ruiz@gmail.com", "923714797"))
        contacts.add(Contact("Norley Cotrina", "norley.cotrina@gmail.com", "974782246"))
       return contacts
    }
}

