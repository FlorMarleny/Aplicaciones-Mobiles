package tecsup.edu.contacto

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetalleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val codeText = findViewById<TextView>(R.id.codeText)
        val fullnameText = findViewById<TextView>(R.id.fullnameText)
        val amountText = findViewById<TextView>(R.id.amountText)

        setContentView(R.layout.activity_detalle)


        if (this.intent.extras != null) {
            if (this.intent.extras!!["code"] != null) {
                val code = this.intent.extras!!.getInt("code")
                codeText.text = code.toString()
            }


            if (this.intent.extras!!["fullname"] != null) {
                val fullname = this.intent.extras!!.getString("fullname")
                fullnameText.text = fullname
            }
            if (this.intent.extras!!["amount"] != null) {
                val amount = this.intent.extras!!.getDouble("amount")
                amountText.text = amount.toString()
            }
        }


    }
}
